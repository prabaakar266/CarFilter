import React, { useState, useMemo } from "react";
import { useSelector } from "react-redux";
import Home from "./Home";
const FilterPage = () => {
     const carData = useSelector((state) => state.carDetails);

     console.log("carData", carData);
     const [filters, setFilters] = useState({
          model: "",
          color: "",
          yearOfManufacture: "",
          insuranceValidUpto: "",
          kms: "",
          location: "",
          noOfOwners: "",
          transmission: "",
          externalFitments: "",
     });
     const handleFilterChange = (field, value) => {
          setFilters({
               ...filters,
               [field]: value,
          });
     };
     const filteredData = useMemo(() => {
          if (!Array.isArray(carData)) {
               return [];
          }

          return carData.filter((car) => {
               return Object.entries(filters).every(([field, filterValue]) => {
                    return (
                         !filterValue ||
                         (car[field] &&
                              car[field]
                                   .toLowerCase()
                                   .includes(filterValue.toLowerCase()))
                    );
               });
          });
     }, [carData, filters]);

     return (
          <div>
               <Home />
               <div className="filter-page">

               <h2>Filter Results:</h2>
               {Object.entries(filters).map(([field, value]) => (
                    <div key={field}>
                         <label>{field.charAt(0).toUpperCase()+field.slice(1)}:</label>
                         <input
                              type="text"
                              value={value}
                              onChange={(e) =>
                                   handleFilterChange(field, e.target.value)
                              }
                         />
                    </div>
               ))}
               </div>

               <div >
                    <h2>Filtered Results:</h2>
                    {filteredData.length>0?
                    <ul>
                         {filteredData.map((car, index) => (
                              <li key={index}>{JSON.stringify(car)}</li>
                         ))}
                    </ul>:<p>No Result Found</p>
}
               </div>
          </div>
     );
};

export default FilterPage;
