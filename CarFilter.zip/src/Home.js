import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import LogoForm from './Logo';
import './App.css';
import { useDispatch } from 'react-redux';
import { clearCarDetails } from './redux/actions/actions';

const Home = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();

  const handleMenuClick = (page) => {
    navigate('/' + page);
  };

  const handleReset = () => {
    dispatch(clearCarDetails());
    alert('Reset Successfully');
  };

  const isfilter = location.pathname === '/filter';

  return (
    <div>
      <div className="menu-container padding header-label">
        <label  onClick={() => handleMenuClick('')}>Logo</label>
        <label  onClick={() => handleMenuClick('filter')}>Filter</label>
        <label  onClick={handleReset}>Clear Data</label>
      </div>

      {!isfilter && <LogoForm />}
    </div>
  );
};

export default Home;
