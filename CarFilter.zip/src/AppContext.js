import React, { createContext, useState } from 'react';

export const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [sharedData, setSharedData] = useState(null);

  const updateSharedData = (newData) => {
    setSharedData(newData);
  };

  return (
    <AppContext.Provider value={{ sharedData, updateSharedData }}>
      {children}
    </AppContext.Provider>
  );
};
