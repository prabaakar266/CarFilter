import React, { useContext, useState, useEffect } from "react";
import { connect } from "react-redux";
import { addCarDetails } from "./redux/actions/actions";
import { AppContext } from './AppContext';

const Details = (props) => {
     const { sharedData } = useContext(AppContext);
     const { formSubmitted, setFormSubmitted } = props;

     const [formData, setFormData] = useState({
          model: sharedData,
          color: "",
          yearOfManufacture: "",
          insuranceValidUpto: "",
          kms: "",
          location: "",
          noOfOwners: "",
          transmission: "",
          externalFitments: "",
     });

     const years = Array.from({ length: new Date().getFullYear() - 2000 + 1 }, (_, index) => 2000 + index);
     const indianCities = [
          "Mumbai",
          "Delhi",
          "Bangalore",
          "Hyderabad",
          "Chennai",
          "Kolkata",
          "Ahmedabad",
          "Pune",
          "Surat",
          "Jaipur",
     ];
     const kmsOptions = [10000, 25000, 50000, 100000];

     const handleInputChange = (field, value) => {
          setFormData({
               ...formData,
               [field]: value,
          });
     };

     const handleFormSubmit = () => {
          const jsonData = {
               ...formData,
          };

          console.log(jsonData);
          props.addCarDetails(jsonData);

          setFormSubmitted(true);
     };

     useEffect(() => {
          setFormData((prevFormData) => ({
               ...prevFormData,
               model: sharedData&&sharedData
                    .charAt(0)
                    .toUpperCase() +
                    sharedData.slice(1),
          }));
     }, [sharedData]);

     console.log(formData, 'formData')
     return (
          <div className="car-details-form">
               <h2>Enter the Car Details:</h2>

               {formSubmitted ? (
                    <div>
                         <h3>JSON Values:</h3>
                         <pre>{JSON.stringify(formData, null, 2)}</pre>
                    </div>
               ) : (
                    <div>
                         <div className="form-row">
                              <label className="input-container">
                                   Model:
                                   <input
                                        type="text"
                                        value={
                                             formData.model !== ""
                                                  ? formData.model
                                                  : sharedData
                                                       .charAt(0)
                                                       .toUpperCase() +
                                                  sharedData.slice(1)
                                        }
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "model",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                              <label className="input-container">
                                   Color:
                                   <input
                                        type="text"
                                        value={formData.color}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "color",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                         </div>
                         <div className="form-row">
                              <label className="input-container">
                                   Year of Manufacture:
                                   <select
                                        value={formData.yearOfManufacture}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "yearOfManufacture",
                                                  e.target.value
                                             )
                                        }
                                   >
                                        <option value="">Select Year</option>
                                        {years.map((year) => (
                                             <option key={year} value={year}>
                                                  {year}
                                             </option>
                                        ))}
                                   </select>
                              </label>
                              <label className="input-container">
                                   Insurance Valid Upto:
                                   <select
                                        value={formData.insuranceValidUpto}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "insuranceValidUpto",
                                                  e.target.value
                                             )
                                        }
                                   >
                                        <option value="">Select Year</option>
                                        {years.map((year) => (
                                             <option key={year} value={year}>
                                                  {year}
                                             </option>
                                        ))}
                                   </select>
                              </label>
                         </div>
                         <div className="form-row">
                              <label className="input-container">
                                   Kms:
                                   <select
                                        value={formData.kms}
                                        onChange={(e) =>
                                             handleInputChange("kms", e.target.value)
                                        }
                                   >
                                        <option value="">Select Kms</option>
                                        {kmsOptions.map((option) => (
                                             <option key={option} value={option}>
                                                  {`>${option}`}
                                             </option>
                                        ))}
                                   </select>
                              </label>
                              <label className="input-container">
                                   Location:
                                   <select
                                        value={formData.location}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "location",
                                                  e.target.value
                                             )
                                        }
                                   >
                                        <option value="">Select City</option>
                                        {indianCities.map((city) => (
                                             <option key={city} value={city}>
                                                  {city}
                                             </option>
                                        ))}
                                   </select>
                              </label>
                         </div>
                         <div className="form-row">
                              <label className="input-container">
                                   No of Owners:
                                   <input
                                        type="number"
                                        value={formData.noOfOwners}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "noOfOwners",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                              <label className="input-container">
                                   Transmission:
                                   <select value={formData.transmission} onChange={(e) =>
                                        handleInputChange(
                                             "transmission",
                                             e.target.value
                                        )
                                   }>
                                        <option value="">Select Transmission</option>
                                        <option value="Automatic">Automatic</option>
                                        <option value="Manual">Manual</option>

                                   </select>
                              </label>
                         </div>
                         <div className="form-row">
                              <label className="input-container">
                                   External Fitments:
                                   <input
                                        type="text"
                                        value={formData.externalFitments}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "externalFitments",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                              <label className="input-container">
                                   Browse:
                                   <input type="file" />
                              </label>
                         </div>
                         <div className="form-row">
                              <button type="button" onClick={handleFormSubmit}>
                                   Submit
                              </button>
                         </div>
                    </div>
               )}
          </div>
     );
};
const mapStateToProps = (state) => {
     return {
          carDetails: state.carDetails,
     };
};

const mapDispatchToProps = {
     addCarDetails,
};

export default connect(mapStateToProps, mapDispatchToProps)(Details);
