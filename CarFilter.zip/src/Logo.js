import React, { useState, useEffect, useContext } from "react";
import Details from "./Details";
import "./App.css";
import { AppContext } from './AppContext';

const LogoForm = () => {
  const carNames = [
    "volvo", "audi", "benz", "bmw", "ford", "honda", "hyundai", "jaguar", "jeep", "kia", "nissan", "tesla", "toyota",
  ];
  const { updateSharedData } = useContext(AppContext);

  const imagesPerRow = 7;

  const [selectedCar, setSelectedCar] = useState(null);
  const [formSubmitted, setFormSubmitted] = useState(false);


  const handleClick = (carName) => {
    setSelectedCar(carName);
    setFormSubmitted(false);
  };

  const renderRows = () => {
    const rows = [];
    for (let i = 0; i < carNames.length; i += imagesPerRow) {
      const row = carNames.slice(i, i + imagesPerRow);
      rows.push(
        <div key={i / imagesPerRow} className="image-row">
          {renderColumns(row)}
        </div>
      );
    }
    return rows;
  };

  const renderColumns = (row) => {
    return row.map((carName, index) => (
      <div
        key={index}
        className="image-column"
        onClick={() => handleClick(carName)}
      >
        <img
          src={`${process.env.PUBLIC_URL}/images/${carName}.png`}
          alt={carName.charAt(0).toUpperCase() + carName.slice(1)}
          width="80"
          height="80"
        />
        <h4 style={{ color: "gray" }}>
          {carName.charAt(0).toUpperCase() + carName.slice(1)}
        </h4>
      </div>
    ));
  };

  useEffect(() => {
    if (selectedCar !== null) {
      updateSharedData(selectedCar);
    }
  }, [selectedCar, updateSharedData]);

  return (
    <div>
      {renderRows()}
      {selectedCar && <Details setFormSubmitted ={setFormSubmitted} formSubmitted ={formSubmitted}/>}
    </div>
  );
};

export default LogoForm;
