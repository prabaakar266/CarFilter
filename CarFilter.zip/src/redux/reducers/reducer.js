import { persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";

const initialState = {
     carDetails: [], 
};

const rootReducer = (state = initialState, action) => {
     switch (action.type) {
          case "ADD_CAR_DETAILS":               
               return {
                    ...state,
                    carDetails: [...state.carDetails, action.payload],
               };
          case "CLEAR_CAR_DETAILS":
               return {
                    ...state,
                    carDetails: [],
               };
          default:
               return state;
     }
};

const persistConfig = {
     key: "root",
     storage,
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

export default persistedReducer;
